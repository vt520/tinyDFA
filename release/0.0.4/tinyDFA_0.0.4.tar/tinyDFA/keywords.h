#ifndef _tinyDFA_keywords_h
#define _tinyDFA_keywords_h



#include "structure.h" // Must Preload Structures _before_ we load keywords
#include "keywords/state.h"
#include "keywords/device.h"





#endif