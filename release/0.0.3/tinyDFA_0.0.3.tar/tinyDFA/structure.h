#ifndef _tinyDFA_structure_h
#define _tinyDFA_structure_h

#include "structure/state.h"
#include "structure/device.h"

#endif