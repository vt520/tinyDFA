#ifndef _tinyDFA_keywords_state_timekeeping 
#define _tinyDFA_keywords_state_timekeeping



#endif