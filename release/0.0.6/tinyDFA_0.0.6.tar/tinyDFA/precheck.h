#ifndef _tinyDFA_precheck_h
#define _tinyDFA_precheck_h

// perform Version Testing if to bork if
// this library is _not_ what they expect
#endif